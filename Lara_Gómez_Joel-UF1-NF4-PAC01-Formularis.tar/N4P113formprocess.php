<html> 
<head> 
<title>Sumar.</title> 
</head> 

<body> 
    <select name="resultado">
        <option value="name"><?php echo $_POST['name']?></option>
        <option value="comentarios"><?php echo $_POST['comentarios']?></option>
        <option value="comentarios"><?php echo $_POST['estrellas']?></option>
    </select>
</body>
</html>