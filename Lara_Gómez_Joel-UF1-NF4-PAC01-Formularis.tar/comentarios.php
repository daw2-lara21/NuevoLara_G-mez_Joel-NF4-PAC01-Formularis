<?php
    echo "He recordado cosas del CSS";
    echo "He refrescado el uso de los formularios";
    echo "Uso de posts";
    echo "Uso de variosinputs";
    echo "Hacer una suma mediante POST";
    echo "Uso de ENDHTML";
    echo "varios tipos de inputs";
    echo "Etiqueta textarea";
    echo "Uso de select";
    echo "He aprendido los tr en PHP";
    echo "La  calificación del documento esta vez le doy un 8, la práctica ha sido sencilla pese a que la 1 no la terminé del todo";
    echo "La explicación del profesor daré un 9 ya que si no fuese por ella no avanzaría";
    echo "Como alumno, estoy algo estresado entre tantas prácticas, pero voy haciendo";
    echo "Ninguna por ahora";
?>

